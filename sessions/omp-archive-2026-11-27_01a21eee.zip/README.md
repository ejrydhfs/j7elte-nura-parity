# Session archive

Generated 2026-11-28T14:52:16.724Z from session `01a21eee-3779-73c1-a2c6-e229bac7a89d`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

45 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main, PanfrostFaultAnalysis, RepoUpdate, KbaseCompare, Mesa203Build, DeconIrqCompare is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (5)

- `DeconIrqCompare` — 151 entries, 1209603 bytes
- `KbaseCompare` — 507 entries, 1917844 bytes
- `Mesa203Build` — 902 entries, 2190993 bytes
- `PanfrostFaultAnalysis` — 146 entries, 1003265 bytes
- `RepoUpdate` — 222 entries, 451654 bytes

## Totals

32 files, 30537830 bytes.
