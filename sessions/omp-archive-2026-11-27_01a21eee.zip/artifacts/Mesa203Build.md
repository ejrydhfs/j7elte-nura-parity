{
  "verdict": "DONE — Mesa 20.3.5 (panfrost+kmsro, no LLVM) built natively on the device for aarch64 musl, installed to /data/mesa203-install, and the smoke test prints GL_RENDERER=\"Mali T720 (Panfrost)\" / GL_VERSION=\"OpenGL ES 3.0 Mesa 20.3.5\". Real fragment jobs retire (no hang, unlike system Mesa 26), but the kernel logs ACCESS_FLAG MMU faults and FBO readback is not run-to-run stable — a kernel MMU defect, not the Mesa build.",
  "source": {
    "what": "mesa git tag mesa-20.3.5 (VERSION file = 20.3.5)",
    "url": "https://gitlab.freedesktop.org/mesa/mesa/-/archive/mesa-20.3.5/mesa-mesa-20.3.5.tar.bz2",
    "sha256": "1ee8069054bdbdd4ef2bb0151ec81070ecf91dca9269f59fd0e7084cc8e45f99",
    "bytes": 16503560,
    "note": "archive.mesa3d.org and mesa.freedesktop.org/archive return 404 for 20.3.5; the GitLab tag archive works. Extracted on device to /data/mesa203-build/src (139.9 MB)."
  },
  "toolchain": {
    "host": "No aarch64 musl cross compiler on the host: only aarch64-linux-gnu-gcc (glibc, 16.2), meson, ninja, no zig, no aarch64-linux-musl-gcc. A glibc cross build cannot load on the musl device, so the build is native on-device (same precedent as the validated 2026-11-20 build).",
    "device": "gcc (Alpine 15.2.0) 15.2.0, musl 1.2.6-r6, meson 1.12.1-r0, ninja (/usr/sbin/ninja), python3 3.14.10, py3-mako 1.3.12, pkgconf 3.0.11, libdrm-dev 2.4.134, wayland-dev 1.26.0 + wayland-scanner, libx11/xext/xrandr/xshmfence/xcb dev, bison, flex. No apk installs were needed; every dependency was already present."
  },
  "meson_flags": {
    "setup_command": "meson setup build src --prefix=/data/mesa203-install --libdir=lib -Dgallium-drivers=panfrost -Ddri-drivers= -Dvulkan-drivers= -Dplatforms=wayland,x11 -Dglx=dri -Degl=enabled -Dgbm=enabled -Dopengl=true -Dgles1=enabled -Dgles2=enabled -Dllvm=disabled -Dshared-llvm=disabled -Dbuild-tests=false -Ddri3=disabled -Dgallium-omx=disabled -Dbuildtype=plain -Dc_args=-O2 -Dcpp_args=-O2",
    "then": "meson configure build -Dgallium-drivers=panfrost,kmsro  (incremental, +8 targets: kmsro winsys + megadriver relink)",
    "configure_summary": [
      "EGL: yes, EGL drivers: builtin:egl_dri2",
      "EGL/Vulkan/VL platforms: wayland x11 surfaceless drm",
      "GBM: yes, GLX: DRI-based, OpenGL: yes (ES1: yes ES2: yes)",
      "Gallium drivers: panfrost kmsro, Gallium st: mesa",
      "llvm: no, Vulkan drivers: no, DRI (classic) drivers: no",
      "DRI driver dir: /data/mesa203-install/lib/dri"
    ],
    "deviations_from_validated_build": [
      "-Dplatforms=wayland,x11 instead of x11 only: KWin/Plasma Wayland clients need Mesa's EGL wayland platform.",
      "-Dgallium-drivers=panfrost,kmsro instead of panfrost only: card0 is the exynos/DECON KMS node, so gbm_create_device(card0) needs exynos_dri.so, which in 20.3.5 is the kmsro entry point (docs/reports/mesa-kmsro-build.md). This adds exynos_dri.so + 19 other kmsro names, all hardlinks to the same megadriver.",
      "-Dbuildtype=plain -O2 (no -g) instead of debugoptimized: objects/libs much smaller (12.96 MB megadriver vs ~75 MB) on a device with 2.4 GB free on /data; asserts remain enabled (NDEBUG not defined), so panfrost assertions still fire.",
      "-Dbuild-tests=false kept (glsl gtest trips on gcc 15 headers)."
    ]
  },
  "patches_applied": [
    {
      "file": "/home/asdf/j7elte-nura-parity/code/gpu31/mesa/patches/0007-mesa203-vertex-attribute-array-bounds.patch",
      "how": "patch -p1 -d src (applies cleanly to 20.3.5, hunk at pan_cmdstream.c:1106)",
      "why": "fixes an out-of-bounds write of the synthesised gl_InstanceID attribute descriptor and zeroes the descriptor arrays; real heap corruption for shaders that read gl_VertexID",
      "verified": "grep 'specials' src/src/gallium/drivers/panfrost/pan_cmdstream.c -> lines 1120/1122/1129/1140"
    }
  ],
  "patches_not_applicable": [
    "0004-kbase-slot-count-fix.patch, 0005-panfrost-v52-compat.patch, 0006-kbase-backend-selectable.patch target the newer kbase-backend Mesa (27.0-devel era), not 20.3.5's midgard/panfrost path.",
    "No tiler-heap patch was needed: this kernel's panfrost7580 backs CREATE_BO with shmem (panfrost7580_gem.c: 'no driver-side size cap ... 16 MiB tiler heap is 4096 ordinary pages'), so stock 20.3.5's 16 MB tiler heap works. No syncobj patch needed either: the port now exposes SYNCOBJ_CREATE/DESTROY/HANDLE_TO_FD/FD_TO_HANDLE/WAIT/SIGNAL/RESET (panfrost7580_syncobj.c). Driver reports 1.1, so Mesa sends PANFROST_BO_NOEXEC|HEAP, which the kernel accepts."
  ],
  "install": {
    "prefix": "/data/mesa203-install",
    "size": "16.6 MB",
    "libraries": [
      "lib/libEGL.so.1.0.0 (soname libEGL.so.1) sha256 55c4e789279b58d863a4b8b70aa46d212c423cdaa9920737c8890cdb68ae2892",
      "lib/libGLESv2.so.2.0.0 (soname libGLESv2.so.2) sha256 3cfccde87450cb67a96813ad296729fa5ea10c6c1927f8148514df72da4c2d05",
      "lib/libGLESv1_CM.so.1.1.0",
      "lib/libgbm.so.1.0.0 (soname libgbm.so.1) sha256 3869cbd3e2e1417b151e02e82dd98ad967ea800254ce7620e6047804019a5ade",
      "lib/libglapi.so.0.0.0 (soname libglapi.so.0) sha256 a1aa3543368d9cba3447906523fc2b20b4574df3b59e461777c128064ef9e628",
      "lib/libGL.so.1.2.0 (GLX/DRI)"
    ],
    "dri": [
      "lib/dri/panfrost_dri.so (12964976 B, 22 hardlinks to one inode = the whole gallium megadriver)",
      "lib/dri/exynos_dri.so + armada-drm/hx8357d/ili9225/ili9341/imx-drm/imx-dcss/ingenic-drm/mcde/mediatek/meson/mi0283qt/mxsfb-drm/pl111/repaper/rockchip/st7586/st7735r/stm/sun4i-drm (kmsro entry points)",
      "lib/dri/libgallium_dri.so (extra hardlink added for tools that expect the megadriver name)"
    ],
    "no_swrast": "swrast/kms_swrast deliberately absent (no llvmpipe, no softpipe) so no silent software fallback is possible.",
    "build_tree_kept": "/data/mesa203-build (222.8 MB: src, build, meson logs, mesa203-smoke.c/.binary, dumbprobe.c/.binary, 0007.patch, setup.log, build.log, reconfig.log)",
    "rpath": "none in any installed lib or megadriver (readelf -d: no RPATH/RUNPATH), so LD_LIBRARY_PATH alone selects the stack."
  },
  "runtime_env": {
    "file": "/data/mesa203-env.sh (0644 root:root)",
    "modes": {
      ". /data/mesa203-env.sh": "render-node mode: LD_LIBRARY_PATH=/data/mesa203-install/lib, LIBGL_DRIVERS_PATH=/data/mesa203-install/lib/dri, GBM_BACKENDS_PATH=same, MESA_LOADER_DRIVER_OVERRIDE=panfrost, unsets LIBGL_ALWAYS_SOFTWARE/DRI_PRIME/PAN_MESA_DEBUG/EGL_PLATFORM",
      ". /data/mesa203-env.sh kms": "card0/GBM mode for KWin: same library/driver paths but MESA_LOADER_DRIVER_OVERRIDE is UNSET, so the loader picks exynos_dri.so on card0 and kmsro opens the render node named panfrost",
      ". /data/mesa203-env.sh system": "reset to stock Mesa 26.3"
    },
    "runner": "/data/mesa203-run-smoke.sh (0755): `sh /data/mesa203-run-smoke.sh [both|surfaceless|gbm]`, or `rootshell /bin/sh /data/mesa203-run-smoke.sh kms` for card0 (needs root: card0 is root:video 0660)."
  },
  "smoke_output_verbatim": {
    "command": "sh /data/mesa203-run-smoke.sh   (sources render mode; EGL_PLATFORM=surfaceless; /data/mesa203-build/mesa203-smoke both /dev/dri/renderD128)",
    "surfaceless": [
      "SMOKE: [surfaceless] EGL_VERSION=1.4 EGL_VENDOR=Mesa Project",
      "SMOKE: [surfaceless] GL_VENDOR=\"Panfrost\"",
      "SMOKE: [surfaceless] GL_RENDERER=\"Mali T720 (Panfrost)\"",
      "SMOKE: [surfaceless] GL_VERSION=\"OpenGL ES 3.0 Mesa 20.3.5\"",
      "SMOKE: [surfaceless] GL_SHADING_LANGUAGE_VERSION=\"OpenGL ES GLSL ES 3.00\"",
      "SMOKE: [surfaceless] fragment-job csum=0x83bb99d80da181cb RENDERED"
    ],
    "gbm_render_node": [
      "SMOKE: [gbm] node=/dev/dri/renderD128 gbm=... backend=drm",
      "SMOKE: [gbm] gbm_surface 720x1280 + EGL window surface created",
      "SMOKE: [gbm] GL_VENDOR=\"Panfrost\"",
      "SMOKE: [gbm] GL_RENDERER=\"Mali T720 (Panfrost)\"",
      "SMOKE: [gbm] GL_VERSION=\"OpenGL ES 3.0 Mesa 20.3.5\"",
      "SMOKE: [gbm] fragment-job csum=0x83bb99d80da181cb RENDERED",
      "SMOKE: [gbm] eglSwapBuffers ok",
      "SMOKE: RESULT PASS"
    ],
    "independent_second_opinion": [
      "$ . /data/mesa203-env.sh; eglinfo -p surfaceless -B",
      "EGL vendor string: Mesa Project",
      "OpenGL compatibility profile renderer: Mali T720 (Panfrost) / version: 2.1 Mesa 20.3.5",
      "OpenGL ES profile renderer: Mali T720 (Panfrost) / version: OpenGL ES 3.0 Mesa 20.3.5"
    ],
    "wall_time": "~3 s for a full surfaceless run (EGL init, shader compile, draw, glFinish, readPixels); no hang under `timeout 25`."
  },
  "how_to_run": {
    "render_debug": ". /data/mesa203-env.sh && EGL_PLATFORM=surfaceless eglinfo -B    # or glmark2 --backend=... only offscreen on renderD128",
    "kwin_wayland (intended path, currently blocked by card0 dumb buffers)": "rootshell /bin/sh -c '. /data/mesa203-env.sh kms; exec /usr/sbin/kwin_wayland --drm --no-lockscreen --socket kwin-test'   # KWIN_DRM_DEBUG / QT_LOGGING_RULES=kwin_wayland_drm.debug=true for the gbm/kmsro decision",
    "kmscube": "rootshell /bin/sh -c '. /data/mesa203-env.sh kms; timeout 20 kmscube -D /dev/dri/card0'",
    "session": "any launcher (startplasma-wayland/plasma_session/kwin_wayland_wrapper) must inherit the kms-mode variables; do NOT set EGL_PLATFORM there and do NOT force MESA_LOADER_DRIVER_OVERRIDE, since that would pin panfrost_dri.so onto the exynos card0 fd."
  },
  "blockers_found": [
    {
      "severity": "blocks KWin-on-card0 (kernel, not Mesa)",
      "what": "card0 kmsro join succeeds — exynos_dri.so loads and kmsro opens /dev/dri/renderD128 (LIBGL_DEBUG: 'drmOpenDevice: node name is /dev/dri/renderD128 ... OK') — then DRM_IOCTL_MODE_CREATE_DUMB returns ENOMEM and Mesa segfaults.",
      "measured": "dumbprobe /dev/dri/card0: 16x16x32 ok (1 KB), 128x128x32 ok (64 KB), 720x1280x16 ok (1843200 B), 720x1280x32 FAIL errno=12 (3686400 B). Kernel log: 'exynos7580-decon-drm 14830000.decon_fb: failed to allocate buffer with size 3686400'.",
      "cause": "exynos/decon dumb buffers are dma_alloc_attrs-backed and the coherent pool cannot serve another 3.6 MB (the /dev/fb0 720x1280x32 framebuffer already holds one such block; no cma= reservation on the cmdline). gbm_surface(USE_SCANOUT) on card0 therefore cannot allocate.",
      "fix_owner": "kernel/boot slice: shmem-backed dumb buffers for exynos7580, larger cma= reservation, or freeing/reducing the fbdev buffer."
    },
    {
      "severity": "rendering not yet pixel-correct (kernel MMU)",
      "what": "Every draw logs 4 GPU MMU faults and the FBO readback is not stable: 'panfrost7580: MMU fault AS0: ACCESS_FLAG/READ stat 810002d8' at page-aligned 0x29dcb000/0x29dcb100/0x29dcb200 and 0x299a55c0, followed by p7580_job: irq-enter rawstat=0x2 (x3) and rawstat=0x1 (fragment).",
      "evidence": "Surfaceless checksum alternates between exactly two values across 6 runs (0x83bb99d80da181cb / 0xc8a6259ce7a13383); a second glReadPixels 300 ms after glFinish always differs from the first (0xf965123315e6ae40, sometimes 0x0) — stale/garbage readback, not a fence hang. PAN_MESA_DEBUG=sync does not change it.",
      "cause_hypothesis": "kernel page-table/access-flag handling for the job's BOs on kernel #40 (scratch-k94 panfrost7580_mmu.c sets AF=(1<<10) on leaf ATEs only); the same Mesa binaries read back a stable checksum on the #37-era evidence, so this is a kernel regression, not the build. Reported to peer KbaseCompare (MMU defines) with addresses/status words.",
      "note": "Jobs do retire (glFinish/readPixels/eglSwapBuffers all return in ~3 s), which is already better than system Mesa 26's never-retiring fragment job."
    }
  ],
  "notes": [
    "Device rebooted twice mid-build (kernel #39 -> #40 flashes by another slice); the build tree survived and ninja resumed each time. /data/mesa203-build keeps everything needed to rebuild incrementally.",
    "Build totals: 1055 targets for panfrost-only, +8 for kmsro. meson's always-stale vcs_tag (src/git_sha1.h) makes `ninja -n`永远 report 5 pending edges; real runs exit 0 once those are restated.",
    "Executables used for evidence: /data/mesa203-build/mesa203-smoke (source beside it; GBM+surfaceless probe doing a full-screen vertex+fragment job into a 720x1280 FBO, optional SMOKE_DELAY_MS second readback) and /data/mesa203-build/dumbprobe (card0 CREATE_DUMB size matrix).",
    "Installed mesa-demos/kmscube/glmark2 were not run against card0 because the dumb-buffer ENOMEM blocks them; the render-node path is fully proven through gbm_surface + eglSwapBuffers."
  ]
}