{
  "driver": "sensors",
  "verdict": "parity",
  "p1": "PASS 91/91 (100%): k2hh 41/41, cm36672p 15/15, stk3013 21/21, hall 14/14 (hall maps to drivers/input/flip_cover.c, compatible \"hall\"). Only .isra/.constprop compiler clones need naming; no misses. No other sensor/SSP driver present in ROM symbols.",
  "p2": "PASS, no DT deltas: k2hh-i2c@1D, cm36672p@60, stk3013@48 and hall nodes identical in values, including axis map/negate, poll/min intervals, thresholds, trim/transmittance, regulators (ldo3, sm5703_ldo2, ldo34), GPIOs (gpa1-0/4, gpa3-6) and referenced pinctrl groups (sensor_i2c, proximity-int, hall-irq). ROM's unused hs-i2c0-bus group (pud 3) is not referenced; the effective group matches Nura's sensor_i2c (pud 0). No magnetometer/barometer/HRM/sensorhub in ROM.",
  "p3": "PASS: CONFIG_SENSORS=y, SENSORS_K2HH=y, SENSORS_CM36672P=y, SENSORS_STK3013=y, INPUT_FLIP_COVER=y (hall); I2C/INPUT/INPUT_EVDEV/REGULATOR/OF/SYSFS all enabled; Kconfig deps satisfied and Makefiles wired. Config sha512 matches pmaports APKBUILD. Registration is input+sysfs (no IIO) with same device names as ROM. CONFIG_CERTIFY_HALL/HALL_IRQ_CTRL are irrelevant (0 certify_hall symbols in ROM).",
  "p4": "PASS/N-A: no firmware blobs; drivers only optionally read /efs/FactoryApp/{accel_calibration_data,prox_cal} (same strings in ROM vmlinux), absent from system.raw/MANIFEST and handled non-fatally. parity/firmware/files-sensors.list documents no mappings.",
  "patch_paths": [],
  "report_path": "parity/reports/sensors.md",
  "notes": "No kernel gap and no patch produced; kernel tree left clean, pmaports untouched. Residual: no userspace sensor consumer in Nura device package (drivers are not IIO, so iio-sensor-proxy cannot use them) and no /efs calibration on converted devices; no build/boot test possible without an aarch64 toolchain."
}