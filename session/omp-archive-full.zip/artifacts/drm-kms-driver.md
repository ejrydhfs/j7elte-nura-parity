I'll start by surveying the environment and the vendor driver sources.

Now I have the full picture. Let me create the driver skeleton and header.