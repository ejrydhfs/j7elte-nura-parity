{
  "gap": "Mesa Panfrost on kbase: standalone kbase winsys (handshake, SAME_VA mem, soft-job/event, fd fences, submit) + pan_kmod kbase backend for Mesa 27 + Gallium screen/context bring-up skeleton and integration map",
  "status": "partial",
  "artifacts": [
    "parity/userspace/gpu/kbase-winsys/include/kbase_winsys.h",
    "parity/userspace/gpu/kbase-winsys/src/kbase_winsys.c",
    "parity/userspace/gpu/kbase-winsys/tests/kbw-selftest.c",
    "parity/userspace/gpu/kbase-winsys/tools/kbw-props-layout.c",
    "parity/userspace/gpu/kbase-winsys/Makefile",
    "parity/userspace/gpu/mesa/src (checkout, branch kbase-winsys, commits 35d495f/6167ac8/4d56405)",
    "parity/patches/gpu-mesa-kbase/0001-panfrost-kmod-add-a-kbase-UK-10.6-backend.patch",
    "parity/patches/gpu-mesa-kbase/0002-gallium-panfrost-make-JM-context-setup-and-submit-ba.patch",
    "parity/patches/gpu-mesa-kbase/0003-gallium-panfrost-add-a-kbase-screen-context-bring-up.patch",
    "parity/patches/gpu-mesa-kbase/apply.sh",
    "parity/reports/gpu-mesa-kbase.md"
  ],
  "build": "Winsys: host x86-64 and aarch64 static builds clean (no warnings); kbw-selftest exits 2 ('no /dev/mali0') on both native and qemu-aarch64; 'make check-abi' measures mali_base_gpu_props=528, GPU_MAX_JOB_SLOTS=16 from the kernel headers and matches all static asserts. Mesa: meson setup with -Dgallium-drivers=panfrost -Dllvm=disabled -Dpanfrost-rust=false -Dmesa-clc=system -Dbuild-tests=true; libpankmod_lib.a (with kbase_kmod.o), libpanfrost.a and libpanfrost-v4.a link; kbase-kmod-selftest links against Mesa and runs (rejects /dev/null, exit 2, no crash); panfrost-kbase-skeleton.c.o compiles against driver headers. All three patches 'git apply --check' clean on pristine Mesa main 02f1337.",
  "blockers": "1) No hardware: /dev/mali0 absent, so handshake/alloc/submit/fence paths were never executed against the GPU; expected outputs and failure modes are documented. 2) Full Mesa link (libgallium_dri and panfrost-kbase-skeleton executable) blocked by environment: Mesa 27's Panfrost builds libpan/OpenCL unconditionally and needs mesa_clc, which requires LLVM; this host has no LLVM and no bindgen. Installing LLVM (mesa_clc builds from the tree) unblocks it. 3) WSI/presentation absent by kernel design: '# CONFIG_DRM is not set', no dma-buf export path usable from the UK 10.6 client, and kbase soft-fence wait accepts only Android sync fences, not dma-buf sync_file fences. 4) Samsung's fence trigger signals success unconditionally in the kernel, so out-fences cannot convey job faults; error reporting needs event-to-fence mapping.",
  "report": "See parity/reports/gpu-mesa-kbase.md for the full milestone report: kernel facts used (handshake, tracking page, 528-byte props layout, SAME_VA semantics, 64-byte atoms, STREAM_CREATE id 536 + soft fence trigger/wait, per-atom events), the winsys API and why it is shaped like pan_kmod, the exact Mesa integration map (device/BO/VM/sync-provider/submit/JM-context hooks), what was built and run, and the ordered remaining work: presentation/Wsi, dma-buf sharing, sync_file interop, fence error reporting, Midgard chain validation on silicon, coherency, multi-context, perf/timestamps, hardware bring-up. No GL rendering is claimed."
}