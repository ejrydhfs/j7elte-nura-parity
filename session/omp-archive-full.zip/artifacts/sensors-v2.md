{
  "gap": "sensors userspace service (net.hadess.SensorProxy bridge for K2HH accel + CM36672P/STK3013 proximity)",
  "status": "implemented",
  "artifacts": [
    "parity/reports/sensors-userspace.md",
    "parity/userspace/sensors/j7elte-sensors.c",
    "parity/userspace/sensors/dbus-wire.c",
    "parity/userspace/sensors/dbus-wire.h",
    "parity/userspace/sensors/Makefile",
    "parity/userspace/sensors/j7elte-sensors.conf",
    "parity/userspace/sensors/j7elte-sensors.service",
    "parity/userspace/sensors/j7elte-sensors.initd",
    "parity/userspace/sensors/tests/run-host-test.sh",
    "parity/userspace/sensors/tests/test-emu.c",
    "parity/userspace/sensors/build-aarch64.log",
    "parity/userspace/sensors/j7elte-sensors-aarch64",
    "parity/pmaports/device/archived/j7elte-sensors/APKBUILD",
    "parity/pmaports/device/archived/j7elte-sensors/Makefile",
    "parity/pmaports/device/archived/j7elte-sensors/j7elte-sensors.c",
    "parity/pmaports/device/archived/j7elte-sensors/dbus-wire.c",
    "parity/pmaports/device/archived/j7elte-sensors/dbus-wire.h",
    "parity/pmaports/device/archived/j7elte-sensors/j7elte-sensors.conf",
    "parity/pmaports/device/archived/j7elte-sensors/j7elte-sensors.service",
    "parity/pmaports/device/archived/j7elte-sensors/j7elte-sensors.initd",
    "parity/patches/userspace/sensors/0001-add-j7elte-sensors-package.patch"
  ],
  "report": "Reviewed the daemon against the live kernel drivers and fixed three real defects. (1) Nura 3.10 input.c:318-322 drops zero-valued EV_REL events, so the old all-three-axes requirement lost samples whenever an axis read exactly 0; the handler now accumulates per SYN_REPORT with missing axis = 0 (reproduced with a uinput probe and covered by the host test). (2) NameOwnerChanged used new_owner's (empty) length instead of name, so claims from vanished clients were never released and sensors stayed enabled; fixed and observed in the test log. (3) The Makefile installed a nonexistent net.hadess.SensorProxy.conf; now installs j7elte-sensors.conf. Verified interfaces: input names accelerometer_sensor/proximity_sensor, EV_REL X/Y/Z plus REL_DIAL/MISC, 4g/8192 LSB per g, /sys/class/input/eventN/device/{enable,poll_delay}, ABS_DISTANCE 0=close/1=far, kernel-side /efs calibration (daemon applies none). Cross-compiled warning-free with aarch64-none-linux-gnu-gcc 10.3.1 static (log: build-aarch64.log; sha256 4104ecd8...); target is musl and no musl toolchain/abuild/arm64 binfmt exists here, so the glibc binary is verification-only. APKBUILD sha512sums re-synced and pass sha512sum -c; make install produces exactly the four expected paths; package installs binary, systemd unit, OpenRC initd and D-Bus policy. D-Bus XML validated via gdbus introspect + xmllint/DtdValid; policy parses with real dbus-daemon; systemd-analyze verify accepts the unit in a minimal root (only dbus.service absent there). Patch applies cleanly to a git archive of pmaports ba682bd and reproduces the aport tree byte-identically. Host uinput integration test PASS (11 assertions incl. orientation/tilt/proximity and the zero-axis case). No hardware was available; the shipped daemon synthesizes no values and the emulator is test-only. Tests to run on main-side: none beyond reviewing the above; on a device, follow the test plan in the report."
}