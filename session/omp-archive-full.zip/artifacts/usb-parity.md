{
  "driver": "usb",
  "verdict": "parity",
  "p1": "PASS - 634/634 ROM symbols accounted: 614 literal matches in Nura source, 20 macro/compiler-generated (6 __initcall wrappers, module_platform_driver init/exit for usbswitch+dwc, module_usb_driver storage, 7 usb_udc sysfs attrs, usb_create_link_device dummy in modem_variation.c:93). Per-block ROM counts: EHCI 56, OHCI 48, OTGD 47, DWC USB2PHY 16, Samsung USBPHY 6, USB switch 19, USB notify 22, generic USB core 420. No real gap; generic usb-audio/hid symbols are outside the controller namespace.",
  "p2": "PASS - zero deltas across six ROM nodes: usb@13580000 (exynos_udc), usb@13510000 (ehci), usb@13520000 (ohci), usb2phy@135c0000 (+usbphy-sys regs), usb-switch (ehci/ohci phandles), usb_notifier. Property-by-property comparison after ignoring legacy linux,phandle duplicate found no differences; clock/IRQ/reg values identical.",
  "p3": "PASS - CONFIG_USB_EHCI_S5P, USB_OHCI_EXYNOS, USB_S3C_OTGD, SAMSUNG_USBPHY, SAMSUNG_DWC_USB2PHY, USB_EXYNOS_SWITCH, USB_NOTIFY_LAYER/USB_NOTIFIER, USB_OTG_WAKELOCK all =y; deps PLAT_S5P=y, ARCH_EXYNOS=y, PM_RUNTIME=y, USB_GADGET=y, USB_PHY=y. ohci-exynos.o is built via #include in ohci-hcd.c:1112, not a missing Makefile entry.",
  "p4": "PASS - no firmware required: no request_firmware()/firmware-name in host, gadget, PHY, switch or notify sources; no firmware DT properties; ROM /etc/firmware and /vendor/firmware contain no USB blob; MANIFEST.sha512 has none. No files-usb.list emitted.",
  "patch_paths": [],
  "report_path": "parity/reports/usb.md",
  "notes": "No patch or patch directory created; kernel tree left clean on owned paths. 3.10 tree has no drivers/phy; PHY drivers live under drivers/usb/phy. Static verification only (no kernel build)."
}