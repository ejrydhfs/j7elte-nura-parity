{
  "driver": "storage",
  "verdict": "parity",
  "p1": "PASS: 113 ROM dw_mci symbols; 106 resolved to drivers/mmc/host/{dw_mmc.c:73, dw_mmc-exynos.c:24, dw_mmc-pltfm.c:9}; other 7 are macro/linker-generated (module_platform_driver -> <drv>_init/_exit via include/linux/device.h:1145-1155 + platform_device.h:208; __initcall_*6 via include/linux/init.h:190) - explained and identical in both trees, effective 113/113.",
  "p2": "PASS: compiled-DT dwmmc0/1/2 + slot@0 are byte-identical between ROM 000_800.dtb and Nura j7elte build (diff of sorted node slices empty). card-detect (broken-cd / cd-type-external / cd-type-gpio+cd-gpio gpa3-4), bus-width 8/4/4, all samsung,dw-mshc-*-timing, clocks, smu/ulp/sdr104 flags match; no vmmc/vqmmc supply in either. Only delta is Nura's additive android fstab node pointing at /dev/block/platform/13540000.dwmmc0/by-name/SYSTEM; all ROM properties have driver consumers (7580 compatible at dw_mmc-exynos.c:1740).",
  "p3": "PASS: CONFIG_MMC=y (2842), MMC_BLOCK=y, MMC_DW=y (2871), MMC_DW_PLTFM=y, MMC_DW_EXYNOS=y (2877), MMC_DW_IDMAC=y (2874), MMC_DW_64_IDMAC=y, FMP=y; Kconfig deps satisfied; Makefile:42-44 builds all three objects.",
  "p4": "PASS: no firmware required - no request_firmware on the dw_mmc path (only vub300, not enabled), no mmc/eMMC blob in parity/firmware/MANIFEST.sha512, tuning computed at runtime; no files-storage.list generated.",
  "patch_paths": [],
  "report_path": "parity/reports/storage.md",
  "notes": "No gap, so no patch and no pmaports config change. Static verification only (no aarch64 toolchain): the 7 generated symbols are inferred from 3.10.108 macros, not from a built Nura binary; ROM 3.10.61 -> Nura 3.10.108 behavioural deltas inside dw_mmc.c cannot be excluded. Kernel tree left clean (`git status --porcelain -- drivers/mmc` empty). Suggested checks: dmesg dwmmc_exynos probe for 13540000/13560000, eMMC rootfs mount, SD insert/remove (gpa3-4), suspend/resume, /sys/kernel/debug/mmc0/ios."
}