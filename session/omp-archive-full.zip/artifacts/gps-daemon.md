{
  "gap": "GPS userspace daemon (BCM4752)",
  "status": "partial",
  "artifacts": [
    "parity/userspace/gps/src/j7elte-gpsd.c",
    "parity/userspace/gps/Makefile",
    "parity/userspace/gps/tests/smoke_test.py",
    "parity/pmaports/device/archived/j7elte-gpsd/APKBUILD",
    "parity/pmaports/device/archived/j7elte-gpsd/j7elte-gpsd.c",
    "parity/pmaports/device/archived/j7elte-gpsd/j7elte-gpsd.conf",
    "parity/pmaports/device/archived/j7elte-gpsd/j7elte-gpsd.initd",
    "parity/pmaports/device/archived/j7elte-gpsd/j7elte-gpsd.service",
    "parity/patches/userspace/gps/0001-pmaports-add-j7elte-gpsd-package.patch",
    "parity/patches/userspace/gps/0002-userspace-add-j7elte-gpsd-source.patch",
    "parity/reports/gps-userspace.md"
  ],
  "report": "Implemented j7elte-gpsd: powers the BCM4752 through /sys/class/sec/gps/GPS_PWR_EN/value (gpio_export_link in sec_gps_bcm4752.c:59, 250 ms GpioDelayMs), opens /dev/ttySAC0 raw 8N1 at 921600 (vendor gps.xml), and forwards only well-formed NMEA to a PTY published at /run/j7elte-gpsd/tty plus a Unix stream socket /run/j7elte-gpsd/nmea.sock; --raw-log captures every received byte for bring-up. No init frame is sent: evidence from /system/bin/gpsd (Broadcom glgps) shows a proprietary ASIC bring-up stack (GlMeSrdAsicinit::Bri_SendAutobaud, Bri_GetOutOfLegacy, Bri_RequestHwVersion, ESW/patch loading, SetRfType/SetRefClockParams, CRC+sequence framed serial layer TXcrc/RXcrc/TXseq/RXseq) and NMEA synthesis inside the daemon (GlEngineImplStd::GetNextNmeaSentence). The Android HAL gps.default.so is a socket client of /dev/socket/gps and never touches the UART, so NMEA is daemon-generated and the chip does not free-run NMEA after power-on. Build: cross-compiled clean (aarch64, -Wall -Wextra -Wshadow -Wformat=2, no warnings); APKBUILD build/package replayed verbatim producing /usr/sbin/j7elte-gpsd, /etc/j7elte-gpsd.conf, /etc/init.d/j7elte-gpsd, /usr/lib/systemd/system/j7elte-gpsd.service; sha512sums verified; both exported patches pass git apply --check against empty trees. Off-target functional test runs the aarch64 binary under qemu-aarch64 with a PTY as UART and a file as GPIO: 8/8 checks pass (power on/off, NMEA to PTY and socket, binary bytes dropped/counted, stable PTY link). Dynamic capture of the vendor init bytes was attempted by running the ROM gpsd under qemu-arm with the dumped /lib, a PTY on /dev/ttySAC0 and the init.rc command line; every bionic binary (gpsd, toybox, sh) deadlocks in the Android 6 linker's g_dl_mutex before main, so no UART trace was obtainable. No hardware available: all verification is cross-compile/static plus qemu; hardware test plan (power pin check, raw-log capture, scope on GPS TX/RX while running stock ROM, gpsd on the PTY, suspend/resume) is in the report.",
  "blockers": "The BCM4752 proprietary init exchange cannot be derived from the available evidence: (1) the autobaud/legacy-exit byte pattern and the ROM boot baud are only function names in the stripped glgps binary, with no packet template or magic literal in the 4 MB image (aa 44 12 does not occur); (2) the frame layout of the Broadcom link (length, CRC polynomial/seed, sequence numbering, message IDs) is code-only; (3) whether the chip transmits anything before the handshake is unknowable without hardware; (4) no ESW/patch image ships in system.raw, so even a reimplementation would need to know whether the ROM path suffices. Hardware capture with --raw-log or a logic analyser is the next step, as spelled out in the test plan."
}