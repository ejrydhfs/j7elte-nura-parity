{
  "gap": "Hardware 3D on Mali-T720 (j7elte) — RE/port assessment plus a verifiable 32-bit ABI prototype",
  "status": "partial",
  "artifacts": [
    "parity/reports/gpu-re.md",
    "parity/userspace/gpu/re-hybris/extract-rom-gles.sh",
    "parity/userspace/gpu/re-hybris/extract-manifest.txt",
    "parity/userspace/gpu/re-hybris/miniloader/miniloader.c",
    "parity/userspace/gpu/re-hybris/miniloader/common.h",
    "parity/userspace/gpu/re-hybris/miniloader/start.S",
    "parity/userspace/gpu/re-hybris/miniloader/Makefile",
    "parity/userspace/gpu/re-hybris/run-prototype.sh",
    "parity/userspace/gpu/re-hybris/logs/miniloader.log",
    "parity/userspace/gpu/re-hybris/logs/bionic-linker.log",
    "parity/userspace/gpu/re-hybris/proto/harness.c",
    "parity/userspace/gpu/re-hybris/proto/start.S",
    "parity/userspace/gpu/re-hybris/proto/Makefile",
    "parity/userspace/gpu/re-hybris/egl_extract/libGLES_mali.so"
  ],
  "blockers": "No j7elte hardware, so nothing is a hardware test and no acceleration is claimed. Path (a) mainline Exynos 7580 + panfrost has no upstream SoC support (6-12+ person-months, design only). Path (b) is blocked as a turnkey solution by: blob is ARM32-only with no 64-bit GL/HAL in the ROM; Nura has no 32-bit userspace; EGL surfaces are Android ANativeWindow/gralloc and hwcomposer.exynos5 needs binder services + 16 Samsung display libs absent from Nura; ROM bionic runtime cannot be validated under qemu-arm (startup fails in the linker: g_dl_mutex wait or 'page record not found'); and the kernel builds r15p0 while the blob is UK 10.0/r7p0, renumbering vendor UK ids (blob's DESTROY_SURFACE=553 is unknown on r15p0 with MALI_SEC_HWCNT off; CREATE_SURFACE=552 aliases TLSTREAM_ACQUIRE and fails the 16-vs-24 byte size check). Path (c) has no T720 artifact: public Midgard binaries are board-specific EULA builds (Odroid-XU3 T628, Juno T624, Firefly RK3288 T760; no T720) and the full DDK is commercial-licence only.",
  "report": "Extracted and hashed the ROM GL stack (/vendor/lib/egl/libGLES_mali.so 23,368,296 B sha256 62e10725…317, ELF32 ARM EABI5, Android 23, interpreter /system/bin/linker; /system/bin/linker; /system/lib/hw/gralloc.exynos5.so 9a822343…; hwcomposer.exynos5.so 6d46e5d5…; libc/libdl); no 64-bit GL stack exists (/lib64 has only libSecMMCodec.so; egl.cfg '0 0 mali'). Path (a): 3.10 has CONFIG_DRM unset, no drm_sched, no GEM shmem helper, no io-pgtable, no panfrost, no DECON/DSIM in drm/exynos, and kbase owns the GPU; mainline 7.3 does match arm,mali-t720 in panfrost but has no Exynos 7580 support (nearest sibling 7870/T830). Path (b) prototype delivered and run: the ROM's own bionic linker resolves the blob's 12 NEEDED libs but the ROM bionic runtime does not start under qemu (traced failure, documented as emulation-only); a freestanding ARM32 ELF loader (APS2/SLEB128 + REL/PLT, 96,168+10,825 relocations, 284 stubs) loads the blob and executes its EGL entry points — eglGetDisplay returns a display object, eglQueryString/eglInitialize run — and intercepts its kbase traffic: open('/dev/mali0'), fstat S_IFCHR, ioctl 0xC0108000 UKP_FUNC_ID_CHECK_VERSION with major=10 minor=0, mmap(4096,PROT_NONE,MAP_SHARED), ioctl 0xC0108212 KBASE_FUNC_SET_FLAGS; the blob's own log confirms 'r7p0-03rel0' and '0x720 r1p0 status range [0..15]'. Static scan of the 23 UK ioctl call sites recovered ids 0/513/514/515/517/518/521/522/526/530/535/539/553/567/568; 553 is the r7p0 DESTROY_SURFACE id that r15p0 renumbers to HWCNT_UTIL_SETUP (undispatched with MALI_SEC_HWCNT off), so exact DDK parity requires building r7p0 (documented config diff, not applied since config is shared). Path (c): confirmed closed/commercial-licence, armv7/EULA board builds only, no T720 artifact, absent from ROM. Recommendation: keep j7elte-gpu-soft; the only maintainable route to hardware 3D is mainline Exynos 7580 + panfrost; path (b) is a viable stopgap only with a 32-bit Android HAL container + libhybris + hwcomposer-to-Wayland bridge and an r7p0 kernel build. No patches produced: no source change is justified (kernel half already complete; userspace needs either a mainline port or a proprietary/Android stack)."
}