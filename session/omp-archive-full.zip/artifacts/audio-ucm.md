{
  "gap": "audio routing (UCM/mixer)",
  "status": "implemented",
  "artifacts": [
    "parity/userspace/audio/rom/mixer_paths.xml",
    "parity/userspace/audio/rom/jack_alsa_mixer.json",
    "parity/userspace/audio/rom/audio_policy.conf",
    "parity/userspace/audio/validate_controls.py",
    "parity/userspace/audio/ucm2/conf.d/Universal7580-I2S/Universal7580-I2S.conf",
    "parity/userspace/audio/ucm2/j7elte/HiFi.conf",
    "parity/userspace/audio/ucm2/j7elte/VoiceCall.conf",
    "parity/pmaports/device/archived/j7elte-audio-ucm/APKBUILD",
    "parity/pmaports/device/archived/j7elte-audio-ucm/Universal7580-I2S.conf",
    "parity/pmaports/device/archived/j7elte-audio-ucm/HiFi.conf",
    "parity/pmaports/device/archived/j7elte-audio-ucm/VoiceCall.conf",
    "parity/pmaports/device/archived/j7elte-audio-ucm/jack_alsa_mixer.json",
    "parity/patches/userspace/audio/0001-device-samsung-j7elte-depend-on-audio-ucm.patch",
    "parity/reports/audio-userspace.md"
  ],
  "report": "Extracted /etc/mixer_paths.xml (96,675 B, 908 <path>, 1,147 <ctl>, 54 distinct controls) and jack_alsa_mixer.json from system.raw (partition root is /, not /system). Chose UCM2 because Alpine alsa-ucm-conf 1.2.16.1 installs only /usr/share/alsa/ucm2 (verified from aports APKBUILD). Card lookup derived from source: card->name/driver = \"Universal7580-I2S\" (soc-core sets shortname/longname/driver from card->name; machine driver sets no driver_name), so the master is installed as conf.d/Universal7580-I2S/Universal7580-I2S.conf with File \"/j7elte/HiFi.conf\". Wrote HiFi (Earpiece, Speaker, Headphones, Mic, Headset Mic on hw:${CardId},0) and VoiceCall (same five devices on hw:${CardId},2) as verbatim translations of the ROM route-ap-tx/route-ap-rx/route-cp/dev-*/gain-* path graph, plus the ROM reset block as SectionVerb sequences. PCM device mapping confirmed: soc_new_pcm is called with the DAI-link index, so pri=0, sec=1, cp=2, bt=3, fm=4, eax0/1=5/6. Automated cross-check (validate_controls.py) enumerates 109 ASoC controls from cod3022x.c (controls + DAPM switch/mixer expansion), s2801x.c with the ASoC \"S2801 \" name_prefix, and the machine driver: result PASS - 54/54 ROM control names exist, 0 missing, 53/53 UCM cset names exist, all enum texts valid and all 114 numeric values inside declared ranges (DAC/ADC <=151, HP <=63, SPK/EP <=15, DNC <=30, S2801 levels <=7, boosts <=3, mic vol <=31). ALSA parse validated with alsaucm 1.2.16 via the virtual-card path (conf.virt.d) because the build host has no matching card: both verbs and all 10 device Value blocks parse (dump text); ${CardId} was dummy-substituted only for that parse run. Package j7elte-audio-ucm (depends=alsa-ucm-conf, plain data, no udev/alsactl state needed) installs the three UCM files plus jack_alsa_mixer.json as reference; a baseline-relative patch adds it to device-samsung-j7elte depends (dry-run verified against pmaports HEAD; not applied per shared-file rule). No kernel tree or shared pmaports files were modified. Jack analysis: sec_jack registers only gpio_event input + switch devices (sec_jack.c:657,663; probe deferral :606), no ALSA kcontrol, and jack_alsa_mixer.json is an Android ALSA-HAL config, so automatic Speaker/Headphones switching via UCM/PipeWire is impossible without a userspace input listener; manual device selection plus hardware test commands (alsaucm/amixer/arecord/evtest) are documented in the report. Static validation only - no hardware available. VoiceCall graph is complete but not end-to-end functional because the cp DAI link uses platform snd-soc-dummy (no modem audio backend).",
  "blockers": "No hardware: playback/capture/jack-detect untested. VoiceCall cannot carry modem audio because the cp DAI link has platform snd-soc-dummy (no Linux modem audio driver/stack for j7elte). No ALSA jack kcontrol exists (sec_jack is input/switch only), so automatic headset routing needs an unvalidated userspace input-event listener."
}