# Session archive

Generated 2026-10-26T04:58:48.443Z from session `01a16c42-0334-7126-841d-1d7a03af4f31`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

107 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main, ril-re, gpu-re, ril-framing, ril-impl, gpu-soft-verify, ril-messages, gpu-kbase, review-kernel, review-userspace-b, review-userspace-a, gpu-panfrost, gpu-libhybris, gps-init-impl, audio-jack, camera-ae, ril-call-re, ril-data-re, ril-sms-re, kbase-compat, ril-impl-2, mali-blob-re, mesa-kbase is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (63)

- `audio-jack` — 273 entries, 774457 bytes
- `audio-parity` — 304 entries, 637161 bytes
- `audio-ucm` — 392 entries, 890773 bytes
- `battery-parity` — 429 entries, 881604 bytes
- `battery-parity-v2` — 153 entries, 381218 bytes
- `battery-power` — 619 entries, 1329815 bytes
- `battery-v2` — 256 entries, 578936 bytes
- `battery-v3` — 315 entries, 803601 bytes
- `bt-parity` — 356 entries, 841775 bytes
- `bt-parity-v2` — 239 entries, 638783 bytes
- `camera-ae` — 460 entries, 1217136 bytes
- `camera-client` — 638 entries, 1675950 bytes
- `camera-parity` — 284 entries, 735938 bytes
- `camera-v2` — 373 entries, 726954 bytes
- `camera-v3` — 388 entries, 944786 bytes
- `connectivity-userscript` — 301 entries, 862242 bytes
- `display-parity` — 324 entries, 777501 bytes
- `display-parity-v2` — 163 entries, 293566 bytes
- `drm-kms-driver` — 503 entries, 1340231 bytes
- `drm-kms-v2` — 317 entries, 815037 bytes
- `drm-kms-v3` — 336 entries, 842839 bytes
- `fde-initramfs` — 293 entries, 668944 bytes
- `gps-daemon` — 383 entries, 874010 bytes
- `gps-init-impl` — 510 entries, 1135349 bytes
- `gps-init-re` — 258 entries, 693055 bytes
- `gps-init-re-v2` — 237 entries, 627275 bytes
- `gps-parity` — 265 entries, 657751 bytes
- `gpu-kbase` — 419 entries, 1148119 bytes
- `gpu-libhybris` — 526 entries, 1429581 bytes
- `gpu-panfrost` — 372 entries, 1133647 bytes
- `gpu-parity` — 337 entries, 758135 bytes
- `gpu-parity-v2` — 156 entries, 459809 bytes
- `gpu-re` — 651 entries, 1687123 bytes
- `gpu-soft-verify` — 267 entries, 684036 bytes
- `gpu-userspace` — 332 entries, 894861 bytes
- `kbase-compat` — 133 entries, 445320 bytes
- `mali-blob-re` — 502 entries, 1640388 bytes
- `mesa-kbase` — 520 entries, 1532473 bytes
- `modem-parity` — 397 entries, 810378 bytes
- `modem-parity-v2` — 239 entries, 714047 bytes
- `platform-parity` — 307 entries, 646073 bytes
- `platform-parity-v2` — 198 entries, 487055 bytes
- `review-kernel` — 261 entries, 826904 bytes
- `review-userspace-a` — 394 entries, 964904 bytes
- `review-userspace-b` — 469 entries, 1173347 bytes
- `ril-call-re` — 319 entries, 1126067 bytes
- `ril-data-re` — 418 entries, 1470379 bytes
- `ril-framing` — 530 entries, 1407907 bytes
- `ril-impl` — 662 entries, 1814887 bytes
- `ril-impl-2` — 836 entries, 2365045 bytes
- `ril-messages` — 644 entries, 1937053 bytes
- `ril-re` — 656 entries, 1677982 bytes
- `ril-sms-re` — 490 entries, 1713695 bytes
- `ril-telephony` — 567 entries, 1372653 bytes
- `ril-v2` — 334 entries, 783105 bytes
- `ril-v3` — 301 entries, 853654 bytes
- `sensors-daemon` — 428 entries, 1265380 bytes
- `sensors-parity` — 198 entries, 453058 bytes
- `sensors-v2` — 263 entries, 846467 bytes
- `storage-parity` — 136 entries, 359511 bytes
- `touch-parity` — 258 entries, 588735 bytes
- `usb-parity` — 266 entries, 667460 bytes
- `wifi-parity` — 247 entries, 589044 bytes

## Totals

317 files, 162742496 bytes.
