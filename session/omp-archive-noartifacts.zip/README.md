# Session archive

Generated 2026-10-26T04:59:02.748Z from session `01a16c42-0334-7126-841d-1d7a03af4f31`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

34 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main, ril-re, gpu-re, ril-framing, ril-impl, gpu-soft-verify, ril-messages, gpu-kbase, review-kernel, review-userspace-b, review-userspace-a, gpu-panfrost, gpu-libhybris, gps-init-impl, audio-jack, camera-ae, ril-call-re, ril-data-re, ril-sms-re, kbase-compat, ril-impl-2, mali-blob-re, mesa-kbase is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (0)

_No subagent sessions were recorded for this session._

## Totals

6 files, 95758300 bytes.
